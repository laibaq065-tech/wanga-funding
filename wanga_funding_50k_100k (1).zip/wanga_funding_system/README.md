# Wanga Funding — connected frontend + backend starter

## What's connected
- The website frontend calls the backend API for plans, account registration/login, session checks, order submission, order history, and admin review.
- User passwords are hashed with bcrypt; session cookies are HttpOnly and SameSite.
- SQLite stores users/orders. Server validates the three plans and fixes the fee to exactly `5.00` USDT.
- Payment reference submissions are recorded as `pending_review`, never auto-approved.
- Admin can approve/reject orders after independent verification.

## Run locally
Requirements: Node.js 20+ and npm.

1. Copy `.env.example` to `.env`.
2. Set a unique random `SESSION_SECRET` (32+ characters), `ADMIN_EMAIL`, and a unique `ADMIN_PASSWORD` (12+ characters).
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

The browser UI and API are served from the same origin. `GET /api/health` is a simple health check.

## Deployment
Deploy this Node.js project to a host that supports a persistent disk (SQLite/session files need persistence) or change the database/session store to managed services.
- Set all `.env.example` variables as host environment variables; never commit `.env`.
- Set `NODE_ENV=production` and serve behind HTTPS.
- Confirm the persistent disk is mounted at `/var/data`; configure `DATA_DIR=/var/data` and `DB_PATH=/var/data/wanga.sqlite` so both `wanga.sqlite` and `sessions.sqlite` persist across restarts.
- The app seeds the admin user from `ADMIN_EMAIL` / `ADMIN_PASSWORD` on first start. Change admin credentials before public launch.
- Test registration, login, logout, submitting an order, and admin status changes on the deployed domain.
- This archive does not deploy itself; you must create a hosting account and deploy it.

## Important limitations before real public launch
1. **No automatic blockchain verification.** The backend stores a transaction hash as pending review. The admin must verify the right chain, USDT token contract, destination wallet, exact 5 USDT received (network fees excluded), confirmations, and whether the transaction has already been used before approving.
2. **No password-reset email or email verification.** UI clearly notes reset is not enabled. Add an email provider and secure single-use reset tokens before public launch.
3. Before public launch, add email verification/password reset, backups, monitoring, abuse controls, independent security review, and legal/compliance review. The production app currently uses a same-origin mutation guard and a persistent SQLite session store; SQLite is intended for a single instance, not multi-instance scaling.
4. Challenge rules are sample values and must be finalized, tested, and published before accepting customer payments.
5. This project is not audited. Do not collect real customer funds until security and payment checks are implemented and tested.

## API
- `GET /api/config`
- `POST /api/auth/register` `{name,email,password}`
- `POST /api/auth/login` `{email,password}`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `POST /api/orders` `{plan,network,tx_hash}` (login required)
- `GET /api/orders` (customer sees own; admin sees all)
- `PATCH /api/admin/orders/:id` `{status,note}` (admin only)


## Advanced additions
- Admin audit log for order status changes (`GET /api/admin/audit`).
- CSV export for orders in the dashboard.
- Same-origin mutation guard in production.
- Render deployment blueprint (`render.yaml`) with a persistent disk for SQLite.

## Deploy to Render (manual action required)
1. Put this project in a Git repository you control (do not include `.env`, databases, or secrets).
2. In Render, create a new Blueprint from that repository and select `render.yaml`.
3. Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` as secret environment values when prompted.
4. Wait for build/deploy; then open the generated `onrender.com` URL and check `/api/health`.
5. Test signup/login/order submission/admin review. Confirm the persistent disk is mounted at `/var/data`.
6. Configure your own domain and DNS if you want a custom domain.

I cannot create the hosting account, accept terms, connect your private Git repo, or publish this project from this chat. You must complete those account-authorized steps yourself.

## Customer support

The site includes a floating **Customer Support** panel with quick FAQs, authenticated ticket submission, and ticket history. Customers must log in to create/track tickets. Admins can open **Support inbox** in the dashboard to set ticket status and send a reply, which customers can see in their ticket history. This is ticket-based support, not live chat; no response-time promise is made. A future enhancement could add email notifications once a verified support email provider is configured.

Support ticket API routes:
- `POST /api/support/tickets` — customer creates a ticket
- `GET /api/support/tickets` — customer sees their tickets; admin sees the inbox
- `PATCH /api/admin/support/tickets/:id` — admin updates status/reply


## Signup par “Failed to fetch” aaye to

Ye aam tor par frontend se backend API tak connection fail hone ka signal hai; email/password ki ghalti ka proof nahi.

1. Project ko poore folder ke saath GitHub repository mein upload karein. Sirf `public/index.html` upload na karein.
2. Render mein **New → Blueprint** se repository connect karein aur root mein `render.yaml` rehne dein. Service ka runtime Node.js hona chahiye; Static Site nahi.
3. Render environment mein `ADMIN_EMAIL` aur `ADMIN_PASSWORD` set karein. `SESSION_SECRET` Blueprint se generate hota hai.
4. Deploy complete hone par `https://YOUR-SERVICE.onrender.com/api/health` kholein. JSON response aana chahiye.
5. Website ka homepage usi Render service se open karein, phir signup dobara test karein. Frontend aur `/api` same origin par hone chahiye.
6. Agar health endpoint fail ho, Render **Logs** mein missing environment variables, npm build errors, ya SQLite errors dekhein.

Note: Is chat se aapke hosting account mein deploy karna ya live service ke logs dekhna mumkin nahi jab tak actual public URL / logs share na hon. Is project ko publish karna abhi bhi zaroori hai.
