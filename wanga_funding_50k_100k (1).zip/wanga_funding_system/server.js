import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import session from "express-session";
import SQLiteStoreFactory from "connect-sqlite3";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import crypto from "node:crypto";
import dotenv from "dotenv";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === "production";
const requiredEnv = ["SESSION_SECRET", "ADMIN_EMAIL", "ADMIN_PASSWORD"];
for (const key of requiredEnv) {
  if (!process.env[key]) {
    console.error(`Missing required environment variable: ${key}`);
    process.exit(1);
  }
}
if (process.env.SESSION_SECRET.length < 32) {
  console.error("SESSION_SECRET must be at least 32 characters.");
  process.exit(1);
}

const dataDir = process.env.DATA_DIR || __dirname;
fs.mkdirSync(dataDir, { recursive: true });
const dbPath = process.env.DB_PATH || path.join(dataDir, "wanga.sqlite");
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'customer',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id TEXT PRIMARY KEY,
 user_id INTEGER NOT NULL REFERENCES users(id),
 plan TEXT NOT NULL CHECK(plan IN ('Starter','Pro','Advanced','Scale','Elite')),
 account_size TEXT NOT NULL,
 network TEXT NOT NULL CHECK(network IN ('TRC20','ERC20','BEP20')),
 amount_usdt TEXT NOT NULL DEFAULT '5.00' CHECK(amount_usdt = '5.00'),
 tx_hash TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending_review'
   CHECK(status IN ('pending_review','approved','rejected')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 reviewed_at TEXT,
 review_note TEXT,
 UNIQUE(network, tx_hash)
);
CREATE TABLE IF NOT EXISTS audit_logs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 actor_user_id INTEGER,
 action TEXT NOT NULL,
 target_id TEXT,
 details TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS support_tickets (
 id TEXT PRIMARY KEY,
 user_id INTEGER NOT NULL REFERENCES users(id),
 subject TEXT NOT NULL,
 category TEXT NOT NULL CHECK(category IN ('Payment','Account','Challenge rules','Technical issue','Other')),
 message TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','in_progress','resolved')),
 admin_reply TEXT,
 replied_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
const Store = SQLiteStoreFactory(session);
app.disable("x-powered-by");
if (isProd) app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
// Same-origin guard for browser mutations. API clients must send the app Origin in production.
app.use((req, res, next) => {
  if (!["POST", "PATCH", "PUT", "DELETE"].includes(req.method)) return next();
  const origin = req.get("origin");
  if (isProd && (!origin || origin !== `${req.protocol}://${req.get("host")}`)) {
    return res.status(403).json({ error: "Request origin could not be verified." });
  }
  next();
});
app.use(express.json({ limit: "20kb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false }));
app.use(session({
  store: new Store({ db: "sessions.sqlite", dir: dataDir }),
  name: "wanga.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: isProd, maxAge: 1000 * 60 * 60 * 8 }
}));

const wallets = {
 TRC20: process.env.WALLET_TRC20 || "TNR6Qdf2SqsBDL5g3vSGXzqLy5PzqM27Xx",
 ERC20: process.env.WALLET_ERC20 || "0x1610b34506fba833087e61304ee67fa4b883fa44",
 BEP20: process.env.WALLET_BEP20 || "0x1610b34506fba833087e61304ee67fa4b883fa44"
};
const plans = {
 Starter: { account_size: "$5,000", target: "8%", daily: "4%", max: "8%" },
 Pro: { account_size: "$10,000", target: "8%", daily: "4%", max: "8%" },
 Advanced: { account_size: "$25,000", target: "10%", daily: "4%", max: "8%" },
 Scale: { account_size: "$50,000", target: "10%", daily: "4%", max: "8%" },
 Elite: { account_size: "$100,000", target: "10%", daily: "4%", max: "8%" }
};
const cleanEmail = v => String(v || "").trim().toLowerCase();
const validEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) && v.length <= 254;
const safeUser = u => ({ id: u.id, name: u.name, email: u.email, role: u.role, created_at: u.created_at });
function auth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please log in first." });
  const user = db.prepare("SELECT id,name,email,role,created_at FROM users WHERE id=?").get(req.session.userId);
  if (!user) { req.session.destroy(() => {}); return res.status(401).json({ error: "Session expired." }); }
  req.user = user; next();
}
function admin(req, res, next) {
  if (!req.user || req.user.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  next();
}
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, message: { error: "Too many attempts. Try again later." } });

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "Wanga Funding API" }));
app.get("/api/config", (_req, res) => res.json({ fee: "5.00", networks: Object.keys(wallets), wallets, plans }));

app.post("/api/auth/register", loginLimiter, async (req, res) => {
  const name = String(req.body?.name || "").trim().slice(0, 100);
  const email = cleanEmail(req.body?.email);
  const password = String(req.body?.password || "");
  if (name.length < 2 || !validEmail(email) || password.length < 10 || password.length > 128) {
    return res.status(400).json({ error: "Enter a valid name/email and a password of 10–128 characters." });
  }
  const password_hash = await bcrypt.hash(password, 12);
  try {
    const info = db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)").run(name, email, password_hash);
    req.session.userId = Number(info.lastInsertRowid);
    return res.status(201).json({ user: safeUser(db.prepare("SELECT id,name,email,role,created_at FROM users WHERE id=?").get(req.session.userId)) });
  } catch (e) {
    if (String(e.code).includes("SQLITE_CONSTRAINT")) return res.status(409).json({ error: "An account with that email already exists." });
    console.error(e); return res.status(500).json({ error: "Could not create account." });
  }
});
app.post("/api/auth/login", loginLimiter, async (req, res) => {
  const email = cleanEmail(req.body?.email), password = String(req.body?.password || "");
  if (!validEmail(email) || !password || password.length > 128) return res.status(400).json({ error: "Enter your email and password." });
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  const ok = user ? await bcrypt.compare(password, user.password_hash) : false;
  if (!ok) return res.status(401).json({ error: "Email or password is incorrect." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start session." });
    req.session.userId = user.id;
    res.json({ user: safeUser(user) });
  });
});
app.post("/api/auth/logout", (req, res) => req.session.destroy(err => {
  res.clearCookie("wanga.sid");
  if (err) return res.status(500).json({ error: "Could not log out." });
  res.json({ ok: true });
}));
app.get("/api/auth/me", auth, (req, res) => res.json({ user: safeUser(req.user) }));

app.post("/api/orders", auth, (req, res) => {
  const planName = String(req.body?.plan || "");
  const network = String(req.body?.network || "");
  const txHash = String(req.body?.tx_hash || "").trim();
  if (!plans[planName]) return res.status(400).json({ error: "Choose a valid plan." });
  if (!wallets[network]) return res.status(400).json({ error: "Choose a valid USDT network." });
  if (txHash.length < 16 || txHash.length > 180 || !/^[a-zA-Z0-9]+$/.test(txHash)) {
    return res.status(400).json({ error: "Enter a valid transaction hash." });
  }
  const id = crypto.randomUUID();
  try {
    db.prepare(`INSERT INTO orders(id,user_id,plan,account_size,network,amount_usdt,tx_hash)
      VALUES(?,?,?,?,?,'5.00',?)`).run(id, req.user.id, planName, plans[planName].account_size, network, txHash);
    res.status(201).json({ order: { id, plan: planName, account_size: plans[planName].account_size, network, amount_usdt: "5.00", status: "pending_review" },
      message: "Reference saved for manual review. This is not a payment confirmation." });
  } catch (e) {
    if (String(e.code).includes("SQLITE_CONSTRAINT")) return res.status(409).json({ error: "This network and transaction hash have already been submitted." });
    console.error(e); res.status(500).json({ error: "Could not save order." });
  }
});
app.get("/api/orders", auth, (req, res) => {
  const rows = req.user.role === "admin"
    ? db.prepare(`SELECT o.*,u.email FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC LIMIT 300`).all()
    : db.prepare(`SELECT id,plan,account_size,network,amount_usdt,tx_hash,status,created_at,reviewed_at,review_note FROM orders WHERE user_id=? ORDER BY created_at DESC`).all(req.user.id);
  res.json({ orders: rows });
});
app.post("/api/support/tickets", auth, (req, res) => {
  const subject = String(req.body?.subject || "").trim().slice(0, 120);
  const category = String(req.body?.category || "Other");
  const message = String(req.body?.message || "").trim().slice(0, 3000);
  const categories = ["Payment", "Account", "Challenge rules", "Technical issue", "Other"];
  if (subject.length < 4 || message.length < 10 || !categories.includes(category)) {
    return res.status(400).json({ error: "Enter a subject (4+ characters), choose a category, and write at least 10 characters." });
  }
  const id = crypto.randomUUID();
  db.prepare("INSERT INTO support_tickets(id,user_id,subject,category,message) VALUES(?,?,?,?,?)")
    .run(id, req.user.id, subject, category, message);
  res.status(201).json({ ticket: { id, subject, category, message, status: "open" }, message: "Support request submitted. Keep the ticket ID for reference." });
});
app.get("/api/support/tickets", auth, (req, res) => {
  const tickets = req.user.role === "admin"
    ? db.prepare(`SELECT t.*,u.name AS customer_name,u.email AS customer_email FROM support_tickets t JOIN users u ON u.id=t.user_id ORDER BY CASE t.status WHEN 'open' THEN 0 WHEN 'in_progress' THEN 1 ELSE 2 END, t.updated_at DESC LIMIT 300`).all()
    : db.prepare("SELECT id,subject,category,message,status,admin_reply,replied_at,created_at,updated_at FROM support_tickets WHERE user_id=? ORDER BY created_at DESC LIMIT 100").all(req.user.id);
  res.json({ tickets });
});
app.patch("/api/admin/support/tickets/:id", auth, admin, (req, res) => {
  const status = String(req.body?.status || "in_progress");
  const reply = String(req.body?.reply || "").trim().slice(0, 3000);
  if (!["open", "in_progress", "resolved"].includes(status)) return res.status(400).json({ error: "Invalid ticket status." });
  const current = db.prepare("SELECT id FROM support_tickets WHERE id=?").get(req.params.id);
  if (!current) return res.status(404).json({ error: "Support ticket not found." });
  db.prepare("UPDATE support_tickets SET status=?,admin_reply=?,replied_at=CASE WHEN ?<>'' THEN CURRENT_TIMESTAMP ELSE replied_at END,updated_at=CURRENT_TIMESTAMP WHERE id=?")
    .run(status, reply || null, reply, req.params.id);
  db.prepare("INSERT INTO audit_logs(actor_user_id,action,target_id,details) VALUES(?,?,?,?)")
    .run(req.user.id, "support_ticket_updated", req.params.id, JSON.stringify({status, has_reply: !!reply}));
  res.json({ ok: true, message: "Support ticket updated." });
});

app.get("/api/admin/audit", auth, admin, (req, res) => {
  const logs = db.prepare("SELECT id,actor_user_id,action,target_id,details,created_at FROM audit_logs ORDER BY id DESC LIMIT 200").all();
  res.json({ logs });
});
app.patch("/api/admin/orders/:id", auth, admin, (req, res) => {
  const status = String(req.body?.status || "");
  const note = String(req.body?.note || "").trim().slice(0, 500);
  if (!["approved", "rejected", "pending_review"].includes(status)) return res.status(400).json({ error: "Invalid status." });
  const result = db.prepare("UPDATE orders SET status=?, review_note=?, reviewed_at=CURRENT_TIMESTAMP WHERE id=?")
    .run(status, note || null, req.params.id);
  if (!result.changes) return res.status(404).json({ error: "Order not found." });
  db.prepare("INSERT INTO audit_logs(actor_user_id,action,target_id,details) VALUES(?,?,?,?)")
    .run(req.user.id, "order_status_changed", req.params.id, JSON.stringify({status, note}));
  res.json({ ok: true, message: "Order status updated." });
});

app.use(express.static(path.join(__dirname, "public")));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Unexpected server error." });
});

// Seed admin at startup. Change ADMIN_PASSWORD before deployment.
const adminEmail = cleanEmail(process.env.ADMIN_EMAIL);
if (!validEmail(adminEmail) || process.env.ADMIN_PASSWORD.length < 12) {
  console.error("ADMIN_EMAIL must be valid and ADMIN_PASSWORD must be at least 12 characters.");
  process.exit(1);
}
const adminHash = await bcrypt.hash(process.env.ADMIN_PASSWORD, 12);
const existingAdmin = db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail);
if (!existingAdmin) db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')")
  .run("Wanga Admin", adminEmail, adminHash);
else db.prepare("UPDATE users SET role='admin' WHERE email=?").run(adminEmail);

app.listen(PORT, () => console.log(`Wanga Funding API running on http://localhost:${PORT}`));
